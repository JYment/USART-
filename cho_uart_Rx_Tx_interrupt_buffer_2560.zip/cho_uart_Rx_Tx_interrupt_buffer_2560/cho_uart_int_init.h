void uart0_init();
void uart1_init();
void uart_init();
unsigned char rx0_char(void);
unsigned char rx1_char(void);
void tx0_char(unsigned char data);
void tx1_char(unsigned char data);
