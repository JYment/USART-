// S/W Environment : AVR Studio 7 + WINAVR Compiler
// Target : ATmega2560
// Crystal: 16Mhz
//
// Author : chowk

// UART Communication. Circular Buffer.
// 이 프로그램은 Rx, Tx Interrupt를 이용한 UART 통신과 Circular buffer에 대한 이해를 위한 것이다.
// 실험을 위한 준비:
//   모니터 프로그램(예: OC-Console, Tera Term)을 설치하고 실행 한다.
//   모니터 프로그램의 설정에서 Serial Port, Baudrate 등을 설정 한다.
//     Serial Port 설정: 개발 보오드를 연결 하고 제어판 -> 장치관리자에서 번호 확인 후 설정에서
//     Baudrate: 이 프로그램에서는 19200으로 설정 되었다.
// 동작 설명:
//   프로그램을 실행 하고 Keyboard에 문자를 입력 하면 모니터에 입력된 문자가 출력 된다.
//   입력된 문자는 Circular buffer(최대 8자)에 저장 돤다.
//   8자 보다 많은 문자가 입력되면 Input Buffer Full 메세지가 출력 된다.
//   CR Key를 누르면 Circular buffer에 저장된 문자가 대문자로 변환 되어 모니터에 출력 된다.

#define atmega128
#define FOSC 16000000// Clock Speed
#define BAUD 19200
#define MYUBRR FOSC/16/BAUD-1

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>

#include "cho_circular_buffer.h"
#include "cho_uart_int_init.h"

extern volatile signed char CR_flag;

void init_devices(void);
static int put_char(char c, FILE *stream);

static int put_char(char c, FILE *stream)
{
	tx1_char(c);
	return 0;
	
}

//Initialize all peripherals
void init_devices(void)
{
	cli();                    // disable all interrupts
	uart_init();              // UART 초기화
	circular_buffer_init();
	fdevopen(put_char,0);
	sei();                    // re-enable interrupts
}

int main (void)
{
	init_devices();
	
	printf("UART1 Interrupt: Circular Buffer.\n\r");
	while(1){
		// 문자의 입력과 출력은 Rx, Tx Interrupt 처리 Routine 에서 처리 된다.
	}
	return 0;
}

