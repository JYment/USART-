void uart0_init();
unsigned char rx0_char(void);
void tx0_char(unsigned char data);
