// S/W Environment : AVR Studio 7 + WINAVR Compiler
// Target : ATmega2560
// Crystal: 16Mhz
//
// Author : chowk

// Example : led basic
// 이 프로그램은 Shift Operation과 Interrupt를 이용한 UART 통신을 이해 하도록 하기 위한 예 이다.
// 실험을 위한 준비:
//   모니터 프로그램(예: OC-Console, Tera Term)을 설치하고 실행 한다.
//   모니터 프로그램의 설정에서 Serial Port, Baudrate 등을 설정 한다.
//     Serial Port 설정: 개발 보오드를 연결 하고 제어판 -> 장치관리자에서 번호 확인 후 설정에서
//     Baudrate: 이 프로그램에서는 19200으로 설정 되었다.

// 동작 설명:
//   프로그램을 실행 하고 Keyboard에 L 문자를 입력 하면 LED가 좌측으로 회전 한다.
//   Keyboard에 R 문자를 입력 하면 LED(PORTL)가 우측으로 회전 한다.

#define atmega128

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>

#include "cho_uart1_interrupt_init.h"

#define FOSC 16000000// Clock Speed
#define BAUD 19200
#define MYUBRR FOSC/16/BAUD-1

#define SHIFT_LEFT 0
#define SHIFT_RIGHT 1

void delay_mSec(unsigned int time_ms);
void delay_uSec(unsigned char time_us);
static int put_char(char c, FILE *stream);

void port_init(void)
{
	PORTD |= 0x03;		// External SW PullUp
	DDRD &= (~0x03);	// Input Port : PD0, PD1

	PORTL = 0x00;		// Initialize Output Port
	DDRL  = 0xff;		// PORTL : Output Port
}

//Call this routine to initialize all peripherals
void init_devices(void)
{
	cli();                // disable all interrupts
	port_init();
	uart_init();          // UART 초기화, Interrupt Enable
	fdevopen(put_char,0);
	sei();                // re-enable interrupts
}

static int put_char(char c, FILE *stream)
{
	tx1_char(c);
	return 0;
}

unsigned char led_shift_dir;
int main(void)
{
	init_devices();
	printf("UART1 Interrupt: LED Shift.\n\r");
	printf("SHIFT_LEFT: L   SHIFT_RIGHT: R \n\r");

	led_shift_dir = SHIFT_LEFT;  // Initialize LED direction

	// SW의 상태에 따라 0.5Sec 간격으로 LED의 Turn 상태가 좌 또는 우측으로 Shift 한다.
	PORTL = 0b00000001;
	while(1){
		delay_mSec(500);    // 0.5Sec Delay

		// LED(PORTF)를 좌측으로 회전 한다.
		if(led_shift_dir == SHIFT_LEFT){
			PORTL <<= 1;
			if(PORTL == 0) PORTL = 0b00000001;
		}
		// LED(PORTF)를 우측으로 회전 한다.
		else{
			PORTL >>= 1;
			if(PORTL == 0) PORTL = 0b10000000;
		}
	}
}

// mSec 단위의 Time  Delay를 갖는 함수
// 최대 Delay Time : 65536mSec
void delay_mSec(unsigned int time_ms){

	unsigned int i;
	
	// 1cycle = 1/16000000 -> 0.0625uSec
	// one loop takes 1mSec
	for(i = 0; i < time_ms; i++)
	{
		delay_uSec(250);
		delay_uSec(250);
		delay_uSec(250);
		delay_uSec(250);
	}

}

// uSec 단위의 Time  Delay를 갖는 함수
// 최대 Delay Time : 256uSec
// 1cycle = 1/16000000 -> 0.0625uSec
void delay_uSec(unsigned char time_us){    // time delay(us)

	register unsigned char i;
	for(i = 0; i < time_us; i++)  // 4 cycle +
	{
		asm volatile(" PUSH  R0 ");       // 2 cycle +
		asm volatile(" POP   R0 ");       // 2 cycle +
		asm volatile(" PUSH  R0 ");       // 2 cycle +
		asm volatile(" POP   R0 ");       // 2 cycle +
		asm volatile(" PUSH  R0 ");       // 2 cycle +
		asm volatile(" POP   R0 ");       // 2 cycle = 16 cycle * 0.0625uSec = 1uSec for 16MHz
	}
}
